using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsStore.Pages
{
    public class _CartLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
